// Vita Brawl v2 - original platform fighter for PS Vita (VitaSDK + vita2d)
//
// CONTROLS
//  Stick/D-pad  move (stick direction also picks the attack)   X  jump (double/triple jump)
//  Square       attack: jab / tilts (ground), aerials (air: neutral/fwd/back/up/down)
//  Triangle     smash attack (ground): hold to charge, release to fire. Stick picks direction
//  Circle       special: neutral = fireball, Up+Circle = up-special recovery
//  L            grab (then: Square pummel, or push stick to throw)
//  R            shield. R + left/right = roll, R + down = spot dodge, R in air = air dodge
//  Down + X     drop through floating platform      Down in fall = fast fall
//  Ledge        fall near stage edge to grab it. Up/X climb, Down drop
//  Start        back to character select after a match
#include <psp2/ctrl.h>
#include <vita2d.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>

#define SCR_W 960
#define SCR_H 544
#define FW 36
#define FH 56
#define GRAVITY 0.6f
#define STOCKS 3
#define PI_F 3.14159265f

typedef struct { float x, y, w; int solid; } Platform;
static const Platform plats[] = {
    {230, 380, 500, 1}, {290, 290, 130, 0}, {540, 290, 130, 0},
};
#define NPLATS 3

typedef struct { int total, start, end; float ox, oy, w, h, dmg, base, scale, angle; } Move;
enum { M_JAB, M_FTILT, M_UTILT, M_DTILT, M_NAIR, M_FAIR, M_BAIR, M_UAIR, M_DAIR,
       M_FSMASH, M_USMASH, M_DSMASH, M_UPB, M_GRAB, M_COUNT };
static const Move moves[M_COUNT] = {
    /*JAB   */ {14, 3, 6,   10, 12, 46, 30,  3, 2.5f, .04f, 40},
    /*FTILT */ {22, 6, 10,  10, 12, 58, 30,  7, 4.5f, .09f, 35},
    /*UTILT */ {20, 5, 10, -30,-24, 60, 40,  6, 4.0f, .09f, 85},
    /*DTILT */ {18, 5, 9,   10, 38, 58, 18,  5, 3.5f, .07f, 70},
    /*NAIR  */ {26, 4, 16, -38,  8, 76, 44,  6, 3.5f, .07f, 45},
    /*FAIR  */ {28, 8, 12,  10, 12, 58, 36,  9, 5.0f, .11f, 40},
    /*BAIR  */ {28, 7, 12, -50, 12, 58, 34, 11, 5.5f, .13f, 35},
    /*UAIR  */ {24, 5, 12, -30,-26, 60, 40,  7, 4.5f, .10f, 88},
    /*DAIR  */ {34,12, 18, -20, 44, 40, 34, 10, 4.0f, .08f,-70},
    /*FSMASH*/ {40,16, 21,  10,  8, 78, 44, 16, 7.0f, .22f, 38},
    /*USMASH*/ {38,12, 20, -36,-30, 72, 56, 14, 6.5f, .21f, 88},
    /*DSMASH*/ {36, 8, 18, -46, 38, 92, 20, 12, 6.0f, .18f, 25},
    /*UPB   */ {40, 6, 22, -24,-20, 48, 60,  6, 5.0f, .10f, 88},
    /*GRAB  */ {22, 6, 10,  10, 14, 42, 30,  0, 0, 0, 0},
};
// throws: forward, back, up, down
static const float throws[4][4] = {
    {7, 6.0f, .12f, 40}, {8, 6.5f, .13f, 40}, {6, 6.0f, .12f, 88}, {5, 5.0f, .09f, 70},
};

typedef struct { const char *name; float weight, speed, dmg, jump, grav, fall; int jumps; unsigned color; } Char;
static const Char chars[3] = {
    {"BLAZE", 100, 4.5f, 1.00f, 12.5f, 1.0f, 12, 2, RGBA8(60, 140, 255, 255)},
    {"TANK",  125, 3.6f, 1.15f, 11.5f, 1.1f, 13, 2, RGBA8(240, 170, 40, 255)},
    {"DASH",   82, 6.0f, 0.90f, 13.5f, 0.9f, 11, 3, RGBA8(90, 220, 120, 255)},
};

typedef struct {
    float x, y, vx, vy, pct, shield, chargeMul;
    int ch, facing, onGround, jumps, stocks;
    int atk, mv, hitDone, hitstun, invuln, dropT;
    int shielding, dodgeT, airDodgeUsed, upbUsed, stunT, fastfall;
    int charging, charge, smashMove;
    int ledge, ledgeT, ledgeCD, ledgeSide;
    int held, grabbedBy, holdT, pummelCD, specialCD;
} Fighter;

typedef struct { float ax, ay; int jump, light, smash, smashHeld, special, grab, shieldPressed, shieldHeld; } Input;
typedef struct { float x, y, vx; int owner, active; } Proj;

static Fighter F[2];
static Proj projs[6];
static int hitstop = 0, state = 0, sel = 0, winner = -1;   // state 0 select, 1 play, 2 over

static float sgn(float v) { return v < 0 ? -1.0f : 1.0f; }

static void spawn(int i, float x)
{
    Fighter *f = &F[i];
    int st = f->stocks, ch = f->ch;
    memset(f, 0, sizeof(*f));
    f->stocks = st; f->ch = ch;
    f->x = x; f->y = 80; f->facing = (x < 480) ? 1 : -1;
    f->jumps = chars[ch].jumps; f->shield = 60; f->invuln = 150;
    f->held = f->grabbedBy = -1;
}

static void startMatch(void)
{
    memset(F, 0, sizeof(F)); memset(projs, 0, sizeof(projs));
    F[0].ch = sel; F[1].ch = (sel + 1 + rand() % 2) % 3;
    F[0].stocks = F[1].stocks = STOCKS;
    spawn(0, 330); spawn(1, 590);
    hitstop = 0; winner = -1; state = 1;
}

static void interrupt(int i)
{
    Fighter *f = &F[i];
    f->atk = 0; f->charging = 0; f->shielding = 0;
    if (f->held >= 0) { F[f->held].grabbedBy = -1; f->held = -1; }
}

static void launch(int ai, int bi, float dmg, float base, float scale, float ang, float dirx, float mul)
{
    Fighter *b = &F[bi];
    int wasGround = b->onGround;
    dmg *= chars[F[ai].ch].dmg * mul;
    b->pct += dmg;
    float kb = (base + b->pct * scale) * 1.4f * (100.0f / chars[b->ch].weight) * mul;
    float r = ang * PI_F / 180.0f;
    b->grabbedBy = -1;
    interrupt(bi);
    b->vx = dirx * cosf(r) * kb;
    b->vy = -sinf(r) * kb;
    if (wasGround && b->vy > 0) b->vy = -3;
    b->hitstun = 10 + (int)(kb * 2);
    b->onGround = 0; b->ledge = 0; b->fastfall = 0;
    hitstop = 3 + (int)(dmg / 4); if (hitstop > 12) hitstop = 12;
}

static void startMove(Fighter *f, int m) { f->mv = m; f->atk = moves[m].total; f->hitDone = 0; f->chargeMul = 1.0f; }

static int pickMove(Fighter *f, Input in, int smash)
{
    if (f->onGround) {
        if (fabsf(in.ax) > 0.5f) f->facing = (int)sgn(in.ax);
        if (in.ay < -0.6f) return smash ? M_USMASH : M_UTILT;
        if (in.ay > 0.6f) return smash ? M_DSMASH : M_DTILT;
        if (fabsf(in.ax) > 0.5f) return smash ? M_FSMASH : M_FTILT;
        return smash ? M_FSMASH : M_JAB;
    }
    if (in.ay < -0.6f) return M_UAIR;
    if (in.ay > 0.6f) return M_DAIR;
    if (in.ax * f->facing < -0.5f) return M_BAIR;
    if (in.ax * f->facing > 0.5f) return M_FAIR;
    return M_NAIR;
}

static void spawnProj(int owner)
{
    Fighter *f = &F[owner];
    for (int i = 0; i < 6; i++) if (!projs[i].active) {
        projs[i].active = 1; projs[i].owner = owner;
        projs[i].x = f->x + (f->facing > 0 ? FW : -4); projs[i].y = f->y + 22;
        projs[i].vx = f->facing * 7.0f;
        return;
    }
}

static void updateFighter(int idx, Input in)
{
    Fighter *f = &F[idx], *o = &F[1 - idx];
    const Char *c = &chars[f->ch];
    float prevBottom = f->y + FH;

    if (f->invuln > 0) f->invuln--;
    if (f->dropT > 0) f->dropT--;
    if (f->specialCD > 0) f->specialCD--;
    if (f->ledgeCD > 0) f->ledgeCD--;
    if (f->pummelCD > 0) f->pummelCD--;

    // being held: pinned to grabber
    if (f->grabbedBy >= 0) { f->vx = f->vy = 0; f->x = o->x + o->facing * (FW + 2); f->y = o->y; return; }

    // holding an opponent: pummel / throw / release
    if (f->held >= 0) {
        int dir = -1;
        f->vx = 0; f->holdT--;
        if (in.ay < -0.6f) dir = 2; else if (in.ay > 0.6f) dir = 3;
        else if (in.ax * f->facing > 0.6f) dir = 0; else if (in.ax * f->facing < -0.6f) dir = 1;
        if (dir >= 0) {
            int t = f->held; float dx = (dir == 1) ? -f->facing : f->facing;
            F[t].grabbedBy = -1; f->held = -1;
            launch(idx, t, throws[dir][0], throws[dir][1], throws[dir][2], throws[dir][3], dx, 1.0f);
        } else if (in.light && f->pummelCD == 0) { o->pct += 1.5f; f->pummelCD = 14; }
        else if (f->holdT <= 0) { o->grabbedBy = -1; o->invuln = 20; f->held = -1; }
        return;
    }

    // hanging on the ledge
    if (f->ledge) {
        const Platform *m = &plats[0];
        f->ledgeT++; f->vx = f->vy = 0;
        if (f->ledgeT < 90) f->invuln = 2;
        if (in.jump || in.ay < -0.6f) {
            f->ledge = 0; f->x = f->ledgeSide < 0 ? m->x + 4 : m->x + m->w - FW - 4;
            f->y = m->y - FH; f->onGround = 1; f->jumps = c->jumps; f->invuln = 30; f->ledgeCD = 20;
        } else if (in.ay > 0.6f || f->ledgeT > 360) { f->ledge = 0; f->ledgeCD = 40; f->y += 10; }
        return;
    }

    int canAct = f->hitstun == 0 && f->stunT == 0 && f->dodgeT == 0;
    if (f->hitstun > 0) {
        f->hitstun--; f->vx += in.ax * 0.25f; f->vy += in.ay * 0.12f; f->vx *= 0.985f;   // DI
    } else if (f->stunT > 0) {
        f->stunT--; f->vx *= 0.8f;
    } else if (f->dodgeT > 0) {
        if (--f->dodgeT == 0 && !f->onGround) { f->vx *= 0.5f; f->vy = 0; }
        if (f->onGround) f->vx *= 0.9f;
    }

    if (canAct) {
        // shield / dodge entry
        if (in.shieldPressed) {
            if (f->onGround && f->atk == 0 && !f->charging) {
                if (fabsf(in.ax) > 0.5f) { f->dodgeT = 26; f->vx = sgn(in.ax) * 6.5f; f->invuln = 18; }
                else if (in.ay > 0.6f)   { f->dodgeT = 22; f->vx = 0; f->invuln = 16; }
                else f->shielding = f->shield > 5;
            } else if (!f->onGround && !f->airDodgeUsed && f->atk == 0) {
                f->dodgeT = 24; f->invuln = 20; f->airDodgeUsed = 1; f->vx = in.ax * 5; f->vy = in.ay * 5;
            }
        }
        if (!in.shieldHeld || !f->onGround) f->shielding = 0;

        if (f->dodgeT == 0) {
            int busy = f->atk > 0 || f->charging;

            // jump (also cancels shield)
            if (in.jump && !busy) {
                f->shielding = 0;
                if (in.ay > 0.6f && f->onGround) { f->dropT = 12; f->onGround = 0; }
                else if (f->jumps > 0) { f->vy = f->onGround ? -c->jump : -c->jump * 0.9f; f->jumps--; f->onGround = 0; f->fastfall = 0; }
            }

            if (f->shielding) {
                f->vx = 0; f->shield -= 0.12f;
                if (f->shield <= 0) { f->shielding = 0; f->stunT = 150; f->vy = -8; f->onGround = 0; }
            } else {
                // charging smash
                if (f->charging) {
                    if (in.smashHeld && f->charge < 60) f->charge++;
                    else { startMove(f, f->smashMove); f->chargeMul = 1.0f + f->charge / 60.0f * 0.35f; f->charging = 0; }
                }
                busy = f->atk > 0 || f->charging;

                // actions
                if (!busy) {
                    if (in.grab && f->onGround) startMove(f, M_GRAB);
                    else if (in.smash && f->onGround) { f->smashMove = pickMove(f, in, 1); f->charging = 1; f->charge = 0; }
                    else if (in.light || in.smash) startMove(f, pickMove(f, in, 0));
                    else if (in.special) {
                        if (in.ay < -0.6f && !f->upbUsed) {
                            startMove(f, M_UPB); f->vy = -13; f->vx = in.ax * 3.5f; f->upbUsed = 1; f->onGround = 0; f->fastfall = 0;
                        } else if (f->specialCD == 0) { spawnProj(idx); f->specialCD = 45; }
                    }
                    busy = f->atk > 0 || f->charging;
                }

                // movement
                if (f->onGround) f->vx = busy ? f->vx * 0.7f : in.ax * c->speed;
                else if (f->atk == 0 || f->mv != M_UPB) {
                    f->vx += in.ax * 0.5f;
                    if (f->vx > c->speed) f->vx = c->speed;
                    if (f->vx < -c->speed) f->vx = -c->speed;
                }
                if (!busy && fabsf(in.ax) > 0.2f) f->facing = (int)sgn(in.ax);
                if (!f->onGround && f->vy > 0 && in.ay > 0.7f && f->atk == 0) f->fastfall = 1;
            }
        }
    }
    if (f->atk > 0 && !f->charging) f->atk--;
    if (f->shield < 60 && !f->shielding) f->shield += 0.1f;

    // physics
    if (f->dodgeT == 0 || f->onGround) f->vy += GRAVITY * c->grav;
    float maxFall = f->fastfall ? 18.0f : c->fall;
    if (f->vy > maxFall && f->hitstun == 0) f->vy = maxFall;
    f->x += f->vx; f->y += f->vy;

    f->onGround = 0;
    if (f->vy >= 0) {
        for (int i = 0; i < NPLATS; i++) {
            const Platform *p = &plats[i];
            if (f->dropT > 0 && !p->solid) continue;
            if (f->x + FW > p->x && f->x < p->x + p->w && prevBottom <= p->y + 1 && f->y + FH >= p->y) {
                f->y = p->y - FH; f->vy = 0; f->onGround = 1; f->jumps = c->jumps;
                f->fastfall = 0; f->airDodgeUsed = 0; f->upbUsed = 0;
                break;
            }
        }
    }

    // ledge grab
    if (!f->onGround && f->vy > 0 && canAct && f->atk == 0 && f->ledgeCD == 0 && in.ay < 0.6f) {
        const Platform *m = &plats[0];
        float hand = f->y + 10, cx = f->x + FW / 2;
        if (hand > m->y - 12 && hand < m->y + 50) {
            int side = 0;
            if (cx < m->x && fabsf(f->x + FW - m->x) < 24) side = -1;
            else if (cx > m->x + m->w && fabsf(f->x - (m->x + m->w)) < 24) side = 1;
            if (side && !(o->ledge && o->ledgeSide == side)) {
                f->ledge = 1; f->ledgeSide = side; f->ledgeT = 0; f->vx = f->vy = 0;
                f->jumps = c->jumps; f->upbUsed = 0; f->airDodgeUsed = 0; f->fastfall = 0;
                f->facing = -side; f->invuln = 2;
                f->x = side < 0 ? m->x - FW + 4 : m->x + m->w - 4; f->y = m->y + 8;
            }
        }
    }
}

static void tryHit(int ai)
{
    Fighter *a = &F[ai], *b = &F[1 - ai];
    if (a->atk <= 0 || a->hitDone) return;
    const Move *m = &moves[a->mv];
    int t = m->total - a->atk;
    if (t < m->start || t > m->end) return;
    float acx = a->x + FW / 2;
    float hx = a->facing > 0 ? acx + m->ox : acx - m->ox - m->w, hy = a->y + m->oy;
    if (!(hx < b->x + FW && hx + m->w > b->x && hy < b->y + FH && hy + m->h > b->y)) return;
    if (b->invuln > 0 || b->grabbedBy >= 0) return;

    if (a->mv == M_GRAB) {
        a->hitDone = 1; a->atk = 0; interrupt(1 - ai);
        a->held = 1 - ai; b->grabbedBy = ai; a->holdT = 150 - (int)b->pct; if (a->holdT < 40) a->holdT = 40;
        return;
    }
    float dirx = (b->x + FW / 2 >= acx) ? 1.0f : -1.0f;
    a->hitDone = 1;
    if (b->shielding) {
        b->shield -= m->dmg * a->chargeMul * 1.2f + 2; b->vx = dirx * 2.5f; a->vx -= dirx * 1.5f; hitstop = 4;
        if (b->shield <= 0) { b->shielding = 0; b->stunT = 150; b->vy = -8; b->onGround = 0; }
        return;
    }
    launch(ai, 1 - ai, m->dmg, m->base, m->scale, m->angle, dirx, a->chargeMul);
}

static void updateProjs(void)
{
    for (int i = 0; i < 6; i++) {
        Proj *p = &projs[i];
        if (!p->active) continue;
        p->x += p->vx;
        if (p->x < -20 || p->x > SCR_W + 20) { p->active = 0; continue; }
        int bi = 1 - p->owner; Fighter *b = &F[bi];
        if (b->invuln > 0 || b->grabbedBy >= 0) continue;
        if (p->x + 8 > b->x && p->x - 8 < b->x + FW && p->y + 8 > b->y && p->y - 8 < b->y + FH) {
            p->active = 0;
            if (b->shielding) { b->shield -= 6; if (b->shield <= 0) { b->shielding = 0; b->stunT = 150; } }
            else launch(p->owner, bi, 5, 4.0f, .05f, 30, sgn(p->vx), 1.0f);
        }
    }
}

static void checkKO(int i, float rx)
{
    Fighter *f = &F[i];
    if (f->x < -120 || f->x > SCR_W + 120 || f->y > SCR_H + 150 || f->y < -250) {
        if (--f->stocks <= 0) { state = 2; winner = 1 - i; }
        else { interrupt(i); spawn(i, rx); }
    }
}

static Input aiThink(int i)
{
    Fighter *a = &F[i], *t = &F[1 - i];
    Input in; memset(&in, 0, sizeof(in));
    float cx = a->x + FW / 2, dx = (t->x + FW / 2) - cx, dy = t->y - a->y;
    if (a->grabbedBy >= 0) return in;
    if (a->hitstun > 0) { in.ax = cx < 480 ? 1.0f : -1.0f; return in; }               // DI toward stage
    if (a->held >= 0) {
        if (rand() % 20 == 0) in.ax = (cx > 480 ? 1.0f : -1.0f) * 0.9f; else in.light = rand() % 3 == 0;
        return in;
    }
    if (a->ledge) { in.jump = a->ledgeT > 40; return in; }
    if (cx < plats[0].x || cx > plats[0].x + plats[0].w || a->y > 400) {                 // recover
        in.ax = cx < 480 ? 1.0f : -1.0f;
        if (a->vy > 1 && a->jumps > 0 && rand() % 10 == 0) in.jump = 1;
        if (a->jumps == 0 && !a->upbUsed && a->y > 340 && rand() % 6 == 0) { in.special = 1; in.ay = -1; }
        return in;
    }
    if (a->shielding) { in.shieldHeld = (t->atk > 0 || rand() % 25 != 0); in.ax = 0; return in; }
    if (t->atk > 0 && fabsf(dx) < 110 && a->onGround && rand() % 5 == 0) { in.shieldPressed = in.shieldHeld = 1; return in; }
    if (t->shielding && fabsf(dx) < 60 && a->onGround) { in.grab = 1; return in; }
    if (fabsf(dx) > 60) in.ax = sgn(dx); else if (fabsf(dx) < 25) in.ax = -sgn(dx) * 0.5f;
    if (dy < -70 && a->jumps > 0 && rand() % 25 == 0) in.jump = 1;
    if (fabsf(dx) < 85 && fabsf(dy) < 60 && a->atk == 0 && rand() % 12 == 0) {
        if (a->onGround && rand() % 4 == 0) { in.smash = 1; in.ax = sgn(dx) * 0.8f; }
        else { in.light = 1; in.ax = (rand() % 2) ? sgn(dx) * 0.8f : 0; }
    }
    if (fabsf(dx) > 220 && a->specialCD == 0 && rand() % 50 == 0) in.special = 1;
    return in;
}

static unsigned withAlpha(unsigned c, unsigned a) { return (c & 0x00FFFFFF) | (a << 24); }

static void drawFighter(int i)
{
    Fighter *f = &F[i];
    unsigned col = chars[f->ch].color;
    if (f->invuln > 0 && f->dodgeT == 0 && (f->invuln / 4) % 2) return;
    if (f->stunT > 0) col = RGBA8(170, 80, 200, 255);
    if (f->dodgeT > 0) col = withAlpha(col, 110);
    vita2d_draw_rectangle(f->x, f->y, FW, FH, col);
    float ex = f->facing > 0 ? f->x + FW - 12 : f->x + 4;
    vita2d_draw_rectangle(ex, f->y + 10, 8, 8, RGBA8(255, 255, 255, 255));
    if (f->shielding)
        vita2d_draw_fill_circle(f->x + FW / 2, f->y + FH / 2, 22 + f->shield * 0.45f, RGBA8(120, 200, 255, 110));
    if (f->charging)
        vita2d_draw_rectangle(f->x - 6, f->y - 14, (FW + 12) * f->charge / 60.0f, 6, RGBA8(255, 220, 60, 255));
    if (f->atk > 0 && !f->charging) {
        const Move *m = &moves[f->mv];
        int t = m->total - f->atk;
        if (t >= m->start && t <= m->end) {
            float cx = f->x + FW / 2, hx = f->facing > 0 ? cx + m->ox : cx - m->ox - m->w;
            vita2d_draw_rectangle(hx, f->y + m->oy, m->w, m->h,
                                  f->mv == M_GRAB ? RGBA8(255, 120, 255, 150) : RGBA8(255, 240, 120, 170));
        }
    }
}

static void drawHUD(vita2d_pgf *pgf)
{
    for (int i = 0; i < 2; i++) {
        float bx = i == 0 ? 80 : 640, p = F[i].pct;
        int g = p > 150 ? 0 : (int)(255 - p * 1.6f); if (g < 0) g = 0;
        vita2d_pgf_draw_text(pgf, bx, 462, RGBA8(200, 200, 200, 255), 1.0f, i == 0 ? "YOU" : "CPU");
        vita2d_pgf_draw_textf(pgf, bx, 495, RGBA8(255, 255, g, 255), 1.6f, "%d%%", (int)p);
        for (int s = 0; s < F[i].stocks; s++)
            vita2d_draw_rectangle(bx + s * 26, 508, 18, 18, chars[F[i].ch].color);
        vita2d_draw_rectangle(bx + 110, 480, 60 * 1.2f, 6, RGBA8(40, 40, 60, 255));
        vita2d_draw_rectangle(bx + 110, 480, (F[i].shield > 0 ? F[i].shield : 0) * 1.2f, 6, RGBA8(120, 200, 255, 255));
    }
}

int main(void)
{
    vita2d_init();
    vita2d_set_clear_color(RGBA8(25, 28, 45, 255));
    vita2d_pgf *pgf = vita2d_load_default_pgf();
    sceCtrlSetSamplingMode(SCE_CTRL_MODE_ANALOG);
    srand(1234);
    memset(F, 0, sizeof(F));

    SceCtrlData pad, old; memset(&old, 0, sizeof(old));
    for (;;) {
        sceCtrlPeekBufferPositive(0, &pad, 1);
        unsigned pressed = pad.buttons & ~old.buttons;

        if (state == 0) {
            if (pressed & SCE_CTRL_RIGHT) sel = (sel + 1) % 3;
            if (pressed & SCE_CTRL_LEFT) sel = (sel + 2) % 3;
            if (pressed & SCE_CTRL_CROSS) startMatch();
        } else if (state == 1) {
            Input in; memset(&in, 0, sizeof(in));
            in.ax = (pad.lx - 128) / 128.0f; in.ay = (pad.ly - 128) / 128.0f;
            if (fabsf(in.ax) < 0.2f) in.ax = 0;
            if (fabsf(in.ay) < 0.2f) in.ay = 0;
            if (pad.buttons & SCE_CTRL_LEFT) in.ax = -1;
            if (pad.buttons & SCE_CTRL_RIGHT) in.ax = 1;
            if (pad.buttons & SCE_CTRL_UP) in.ay = -1;
            if (pad.buttons & SCE_CTRL_DOWN) in.ay = 1;
            in.jump = (pressed & SCE_CTRL_CROSS) != 0;
            in.light = (pressed & SCE_CTRL_SQUARE) != 0;
            in.smash = (pressed & SCE_CTRL_TRIANGLE) != 0;
            in.smashHeld = (pad.buttons & SCE_CTRL_TRIANGLE) != 0;
            in.special = (pressed & SCE_CTRL_CIRCLE) != 0;
            in.grab = (pressed & SCE_CTRL_LTRIGGER) != 0;
            in.shieldPressed = (pressed & SCE_CTRL_RTRIGGER) != 0;
            in.shieldHeld = (pad.buttons & SCE_CTRL_RTRIGGER) != 0;

            if (hitstop > 0) hitstop--;
            else {
                updateFighter(0, in);
                updateFighter(1, aiThink(1));
                tryHit(0); tryHit(1);
                updateProjs();
                checkKO(0, 330); checkKO(1, 590);
            }
        } else if (pressed & SCE_CTRL_START) state = 0;
        old = pad;

        vita2d_start_drawing();
        vita2d_clear_screen();
        if (state == 0) {
            vita2d_pgf_draw_text(pgf, 330, 90, RGBA8(255, 255, 255, 255), 2.2f, "VITA BRAWL");
            vita2d_pgf_draw_text(pgf, 290, 140, RGBA8(200, 200, 200, 255), 1.1f, "Left/Right: choose fighter   X: start");
            for (int i = 0; i < 3; i++) {
                float x = 140 + i * 250;
                vita2d_draw_rectangle(x - 6, 196, 172, 206, i == sel ? RGBA8(255, 255, 255, 255) : RGBA8(60, 60, 80, 255));
                vita2d_draw_rectangle(x, 202, 160, 194, RGBA8(35, 38, 60, 255));
                vita2d_draw_rectangle(x + 62, 230, FW, FH, chars[i].color);
                vita2d_pgf_draw_text(pgf, x + 40, 320, RGBA8(255, 255, 255, 255), 1.3f, chars[i].name);
                vita2d_pgf_draw_textf(pgf, x + 14, 350, RGBA8(190, 190, 190, 255), 0.9f, "Wt %d  Spd %.1f", (int)chars[i].weight, chars[i].speed);
                vita2d_pgf_draw_textf(pgf, x + 14, 374, RGBA8(190, 190, 190, 255), 0.9f, "Pwr x%.2f  Jumps %d", chars[i].dmg, chars[i].jumps);
            }
        } else {
            for (int i = 0; i < NPLATS; i++)
                vita2d_draw_rectangle(plats[i].x, plats[i].y, plats[i].w, plats[i].solid ? 40 : 10,
                                      plats[i].solid ? RGBA8(90, 70, 55, 255) : RGBA8(150, 150, 170, 255));
            for (int i = 0; i < 6; i++)
                if (projs[i].active) vita2d_draw_fill_circle(projs[i].x, projs[i].y, 8, RGBA8(255, 150, 40, 255));
            drawFighter(0); drawFighter(1);
            drawHUD(pgf);
            if (state == 2) {
                vita2d_pgf_draw_text(pgf, 340, 200, RGBA8(255, 255, 255, 255), 2.0f, winner == 0 ? "YOU WIN!" : "CPU WINS");
                vita2d_pgf_draw_text(pgf, 330, 250, RGBA8(200, 200, 200, 255), 1.2f, "Press START to continue");
            }
        }
        vita2d_end_drawing();
        vita2d_swap_buffers();
    }
    return 0;
}
